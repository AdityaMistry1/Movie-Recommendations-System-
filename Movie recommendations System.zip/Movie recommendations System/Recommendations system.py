import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import ast

# Load datasets
movies = pd.read_csv("Data/tmdb_5000_movies.csv")
credits = pd.read_csv("Data/tmdb_5000_credits.csv")

# Merge datasets on 'title'
movies = movies.merge(credits, on='title')

# Function to extract top 3 cast
def get_top_cast(text):
    try:
        cast = ast.literal_eval(text)
        return ' '.join([member['name'] for member in cast[:3]])
    except:
        return ''

# Function to extract director
def get_director(text):
    try:
        crew = ast.literal_eval(text)
        for person in crew:
            if person['job'] == 'Director':
                return person['name']
        return ''
    except:
        return ''

# Apply extraction
movies['top_cast'] = movies['cast'].apply(get_top_cast)
movies['director'] = movies['crew'].apply(get_director)

# Combine features: overview + genres + top 3 cast + director
movies['genres'] = movies['genres'].fillna('')
movies['overview'] = movies['overview'].fillna('')
movies['combined'] = movies['overview'] + ' ' + movies['genres'] + ' ' + movies['top_cast'] + ' ' + movies['director']

# TF-IDF Vectorization
tfidf = TfidfVectorizer(stop_words='english')
tfidf_matrix = tfidf.fit_transform(movies['combined'])

# Cosine similarity
cosine_sim = cosine_similarity(tfidf_matrix)

# Movie title to index
indices = pd.Series(movies.index, index=movies['title']).drop_duplicates()

# Lowercase movie titles for matching
indices = pd.Series(movies.index, index=movies['title'].str.lower()).drop_duplicates()

# Recommendation function
def recommend(title, num=5):
    if title not in indices:
        return f"'{title}' not found in the dataset."
    idx = indices[title]
    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)[1:num+1]
    movie_indices = [i[0] for i in sim_scores]
    return movies['title'].iloc[movie_indices]

# Ask user to enter a movie name
while True:
    user_title = input("\nEnter a movie title (or type 'exit' to quit): ").strip().lower()
    if user_title == 'exit':
        print("Goodbye!")
        break

    if user_title not in indices:
        print("Movie not found. Please try again with a different title.")
    else:
        print(f"\nRecommended movies for '{user_title.title()}':")
        recommendations = recommend(user_title)
        for movie in recommendations:
            print("-", movie)